export interface Document {
  id: string;
  studentId: string;
  name: string;
  type: string;
  dataUrl: string;
  createdAt?: string;
}
