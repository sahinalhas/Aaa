export const NAVIGATION_LABELS = {
  STUDENT_MANAGEMENT: 'Öğrenci Yönetimi',
  COURSES_AND_TOPICS: 'Dersler & Konular',
  SETTINGS: 'Ayarlar',
  MEETINGS: 'Görüşmeler',
  SURVEYS: 'Anketler',
  REPORTS: 'Raporlama',
  ACTIVITIES: 'Etkinlikler',
  RISK_INTERVENTION: 'Risk ve Müdahale Takip',
  PERFORMANCE_STATISTICS: 'Performans & İstatistik',
  HOME_PAGE: 'Ana Sayfa',
} as const;
