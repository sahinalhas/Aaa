export const TIME_LABELS = {
  TODAY: 'Bugün',
  YESTERDAY: 'Dün',
  THIS_WEEK: 'Bu Hafta',
  THIS_MONTH: 'Bu Ay',
  DATE: 'Tarih',
  TIME: 'Saat',
} as const;
