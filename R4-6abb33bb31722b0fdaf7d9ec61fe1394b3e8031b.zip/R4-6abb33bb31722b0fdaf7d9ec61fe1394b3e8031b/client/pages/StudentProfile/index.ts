export { default } from "./StudentProfile";
