import Courses from "@/pages/Courses";

export default function CoursesSettingsTab() {
  return (
    <div className="mt-4">
      <Courses />
    </div>
  );
}
